#!/bin/bash
if [ -z ${ARCH} ]; then ARCH=linux-x64; fi

if ! [[ "$ARCH" =~ ^(linux-x64|osx-x64|win-x64)$ ]]; then 
    echo "Architecture $ARCH not supported; please set the environment variable ARCH to one of: linux-x64, osx-x64, win-x64 (example in bash: export ARCH=linux-x64)"
    exit 1
fi

echo "Architecture is $ARCH; to change set the environment variable ARCH to one of: linux-x64, osx-x64, win-x64 (example in bash: export ARCH=linux-x64)"

if [ "$ARCH" == "win-x64" ]; then 
    export SUFFIX=".exe"
fi

OUTPUT=output.png

if [ "$1" == "" ]; then
    cat<<EOF
Usage: "$0" NUMBER_OF_ITERATIONS
(NUMBER_OF_ITERATIONS must be a number; please be kind to bash scripts)
EOF
else    

tmp='int'
for i in $(seq 1 "$1"); do
    tmp="w($tmp)"
done
cat input.imgql > tmp.imgql
echo "save \"$OUTPUT\" $tmp" >> tmp.imgql

cat<<EOF 


Running VoxLogicA-GPU; press CTRL+C to interrupt and lower the number "$1" if this takes too long.

EOF
VOXLOGICA_DEFAULT=../../VoxLogicA-GPU/VoxLogicA_0.6.0-gpu_$ARCH/VoxLogicA$SUFFIX 
${VOXLOGICA:-$VOXLOGICA_DEFAULT} tmp.imgql
mv "$OUTPUT" "GPU-$OUTPUT"

# cat<<EOF 


# Running VoxLogicA-CPU; press CTRL+C to interrupt and lower the number "$1" if this takes too long.

# EOF
# ../../VoxLogicA-CPU/VoxLogicA_0.6.0_$ARCH/VoxLogicA$SUFFIX tmp.imgql
# mv "$OUTPUT" "CPU-$OUTPUT"
# cat<<EOF



# EOF


fi