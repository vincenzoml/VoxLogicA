#!/bin/bash

usage() {
    echo
    echo "usage: $0 basedir scriptname"
    echo "basedir is the base directory where the dataset is located (e.g. brats17)"
    echo "scriptname is the template script name with .imgql extension"
    echo
}

process() {
    OUTPUTDIR="$OUTPUT/$OUTPUTPREFIX/$INPUTDIR"
    EXECUTE="$OUTPUTDIR"/input.imgql
    LOG="$OUTPUTDIR"/log.txt
    mkdir -p "$OUTPUTDIR"
    cat "$SCRIPTNAME" |
	sed 's@$NAME@'"$NAME"'@g' |
	sed 's@$INPUTDIR@'"$INPUTDIR"'@g' |
	sed 's@$OUTPUTDIR@'"$OUTPUTDIR"'@g' > "$EXECUTE"
    echo -n "$SCRIPTNAME started at $(date) on $NAME..."
    echo "$SCRIPTNAME started at $(date) on $NAME" > "$LOG"
    "$VOXLOGICA" "$EXECUTE" >> "$LOG"
    RET=$?
    if [ "$RET" -ne "0" ]; then
	echo " [failed with code $RET (see $LOG for details)]"
    cat $LOG
    else
	echo " [OK]"
    fi
}

canonical() {
    echo "$(dirname "$1")/$(basename "$1")"
}

if [ -z ${ARCH} ]; then ARCH=linux-x64; fi

if ! [[ "$ARCH" =~ ^(linux-x64|osx-x64|win-x64)$ ]]; then 
    echo "Architecture $ARCH not supported; please set the environment variable ARCH to one of: linux-x64, osx-x64, win-x64 (example in bash: export ARCH=linux-x64)"
    exit 1
fi

echo "Architecture is $ARCH; to change set the environment variable ARCH to one of: linux-x64, osx-x64, win-x64 (example in bash: export ARCH=linux-x64)"

if [ "$ARCH" == "win-x64" ]; then 
    export SUFFIX=".exe"
fi


VOXLOGICAGPU="../../VoxLogicA-GPU/VoxLogicA_0.6.0-gpu_$ARCH/VoxLogicA$SUFFIX"
VOXLOGICACPU="../../VoxLogicA-CPU/VoxLogicA_0.6.0_$ARCH/VoxLogicA$SUFFIX"

echo Using executable "$VOXLOGICAGPU"
VOXLOGICA="$VOXLOGICAGPU"
OUTPUT=output
DIR=BRATS
SCRIPTNAME=Template.imgql
OUTPUTPREFIX=$(basename "$SCRIPTNAME" ".imgql")-GPU
STATS="$OUTPUT/$OUTPUTPREFIX-stats.csv"
rm -f "$STATS"
find -L "$DIR" -mindepth 1 -maxdepth 1 -type d -print0 |
while read -d $'\0' INPUTDIR
do NAME=$(basename "$INPUTDIR")
    process
done

echo Using executable "$VOXLOGICACPU"
VOXLOGICA="$VOXLOGICACPU"
OUTPUT=output
DIR=BRATS
SCRIPTNAME=Template.imgql
OUTPUTPREFIX=$(basename "$SCRIPTNAME" ".imgql")-CPU
find -L "$DIR" -mindepth 1 -maxdepth 1 -type d -print0 |
while read -d $'\0' INPUTDIR
do NAME=$(basename "$INPUTDIR")
    process
done



